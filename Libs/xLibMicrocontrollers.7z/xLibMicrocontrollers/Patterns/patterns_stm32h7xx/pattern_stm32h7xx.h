/*
 * pattern_stm32h7xx.h
 *
 * Created: 16.05.2019 14:29:38
 *  Author: rekuts
 */ 
//==============================================================================
#ifndef PATTERN_STM32H7XX_H_
#define PATTERN_STM32H7XX_H_
//==============================================================================
#include "pattern_stm32h7xx_dma.h"
#include "pattern_stm32h7xx_dma2d.h"
#include "pattern_stm32h7xx_i2c.h"
#include "pattern_stm32h7xx_spi.h"
#include "pattern_stm32h7xx_timer.h"
#include "pattern_stm32h7xx_uart.h"
//==============================================================================
#endif /* PATTERN_STM32H7XX_H_ */
