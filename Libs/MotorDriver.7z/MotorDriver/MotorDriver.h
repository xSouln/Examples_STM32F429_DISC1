//==============================================================================
#ifndef MOTOR_DRIVER_H
#define MOTOR_DRIVER_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
#include <stdint.h>
#include "Common/xTypes.h"
//=============================================================================
#define MOTOR_DRIVER_FORWARD_MAX_VALUE 	0x7fffffff
#define MOTOR_DRIVER_BACKWARD_MAX_VALUE 0x80000000
//=============================================================================
typedef enum
{
	MotorDriverMoveDiractionIdle,
	MotorDriverMoveDiractionForward = 1,
	MotorDriverMoveDiractionBackward = -1
	
} MotorDriverMoveDiractions;
//------------------------------------------------------------------------------
typedef enum
{
	MotorDriverHandlerStateInWork,
	MotorDriverHandlerStateError
	
} MotorDriverHandlerStates;
//------------------------------------------------------------------------------
typedef enum
{
	MotorDriverStateDisable,
	MotorDriverStateEnabling,
	MotorDriverStateIsEnable,
	
} MotorDriverStates;
//------------------------------------------------------------------------------
typedef enum
{
	MotorDriverMotorStateStopped,
	MotorDriverMotorStateStartingMove,
	MotorDriverMotorStateInMoving,
	
} MotorDriverMotorStates;
//==============================================================================
typedef enum
{
	MotorDriverEventIdle,
	MotorDriverEventChangeDriverState,
	MotorDriverEventChangeMotorState
	
} MotorDriverEventSelector;
//------------------------------------------------------------------------------
typedef enum
{
	MotorDriverRequestIdle,
	MotorDriverRequestDelay
	
} MotorDriverRequestSelector;
//------------------------------------------------------------------------------
typedef enum
{
	MotorDriverValueIdle,
	MotorDriverValueSpeed,
	MotorDriverValuePosition,
	MotorDriverValueMotorEnableState,
	MotorDriverValueDriverEnableState,
	MotorDriverValueDiraction,
	MotorDriverValueHandlerFrequency,
	MotorDriverValueLockState
	
} MotorDriverValueSelector;
//------------------------------------------------------------------------------
typedef void (*MotorDriverEventListenerT)(void* driver, MotorDriverEventSelector selector, uint32_t args, uint32_t count);
typedef xResult (*MotorDriverRequestListenerT)(void* driver, MotorDriverRequestSelector selector, uint32_t args, uint32_t count);

typedef uint32_t (*MotorDriverActionGetValueT)(void* driver, MotorDriverValueSelector selector);
typedef xResult (*MotorDriverActionSetValueT)(void* driver, MotorDriverValueSelector selector, uint32_t value);
//------------------------------------------------------------------------------
typedef struct
{
	MotorDriverEventListenerT EventListener;
	MotorDriverRequestListenerT RequestListener;
	
	MotorDriverActionGetValueT GetValue;
	MotorDriverActionSetValueT SetValue;
	
} MotorDriverInterfaceT;
//------------------------------------------------------------------------------
typedef union
{
	struct
	{
		uint32_t IsInit : 1;
		uint32_t IsLocked : 1;
		MotorDriverStates DriverState : 3;
		MotorDriverMotorStates MotorState : 3;
		MotorDriverHandlerStates HandlerState : 2;
	};
	
	uint32_t Value;
	
} MotorDriverStatusT;
//------------------------------------------------------------------------------
typedef struct
{
	float Acceleration;
	float Deceleration;
	
	float StartSpeed;
	float StopSpeed;
	
	uint16_t DisableDelay;
	uint16_t EnableDelay;
	
} MotorDriverOptionsT;
//------------------------------------------------------------------------------
typedef struct
{
	float AccelerationStep;
	float DecelerationStep;
	
	uint32_t AccelerationTime;
	uint32_t DecelerationTime;
	
	uint32_t AccelarationSteps;
	uint32_t DeccelarationSteps;
	
	float dxSteps;
	float Steps;
	
	uint32_t HandlerFrequency;
	
} MotorDriverValuesT;
//------------------------------------------------------------------------------
typedef struct
{
	uint32_t AccelerationTime;
	uint32_t DecelerationTime;
	
	uint32_t AccelarationSteps;
	uint32_t DeccelarationSteps;
	
	uint32_t xAccelarationSteps;
	uint32_t xDecelarationSteps;
	
} MotorDriverDebugValuesT;
//------------------------------------------------------------------------------
typedef struct
{
	char* Description;
	void* Parent;
	
	void* Adapter;
	MotorDriverInterfaceT* Interface;
	
	MotorDriverStatusT Status;
	MotorDriverOptionsT Options;
	MotorDriverValuesT Values;
	
	MotorDriverDebugValuesT DebugValues;
	
	int PositionRequest;
	int Position;
	
	int MoveTimeRequest;
	int MoveTime;
	
	float SpeedRequest;
	float Speed;
	
	uint16_t DisableDelay;
	uint16_t EnableDelay;
	
	MotorDriverMoveDiractions Diraction;
	
} MotorDriverT;
//==============================================================================														
void MotorDriverHandler(MotorDriverT* driver);

//xResult MotorDriverStart(MotorDriverT* driver);
xResult MotorDriverStop(MotorDriverT* driver);
																
xResult MotorDriverEnable(MotorDriverT* driver);
xResult MotorDriverDisable(MotorDriverT* driver);

xResult MotorDriverInit(MotorDriverT* driver,
												void* parent,
												void* adapter,
												MotorDriverInterfaceT* interface,
												MotorDriverOptionsT* options);
												
xResult MotorDriverSetPosition(MotorDriverT* driver,
																int position,
																float speed,
																int move_time);
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif /* MOTOR_DRIVER_H */
