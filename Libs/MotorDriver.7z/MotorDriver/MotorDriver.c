//==============================================================================
#include "MotorDriver.h"
#include "Common/xMemory.h"
//==============================================================================
xResult MotorDriverLock(MotorDriverT* driver)
{
	return driver->Interface->SetValue(driver, MotorDriverValueLockState, true);
}
//------------------------------------------------------------------------------
xResult MotorDriverUnlock(MotorDriverT* driver)
{
	return driver->Interface->SetValue(driver, MotorDriverValueLockState, false);
}
//==============================================================================
xResult MotorDriverEnable(MotorDriverT* driver)
{
	if (driver->Status.DriverState == MotorDriverStateDisable)
	{
		driver->EnableDelay = driver->Options.EnableDelay;
		driver->Status.DriverState = MotorDriverStateEnabling;
		driver->Interface->EventListener(driver, MotorDriverEventChangeDriverState, MotorDriverStateEnabling, 0);
	}
	return xResultAccept;
}
//------------------------------------------------------------------------------
xResult MotorDriverDisable(MotorDriverT* driver)
{
	driver->Status.DriverState = MotorDriverStateDisable;
	driver->Interface->EventListener(driver, MotorDriverEventChangeDriverState, MotorDriverStateDisable, 0);
	driver->Interface->SetValue(driver, MotorDriverValueDriverEnableState, false);
	return xResultAccept;
}
//==============================================================================
xResult MotorDriverStop(MotorDriverT* driver)
{
	driver->Status.MotorState = MotorDriverMotorStateStopped;
	driver->PositionRequest = driver->Position;
	driver->Interface->EventListener(driver, MotorDriverEventChangeMotorState, MotorDriverMotorStateStopped, 0);
	driver->Interface->SetValue(driver, MotorDriverValueMotorEnableState, false);
	return xResultAccept;
}
//==============================================================================
void MotorDriverHandler(MotorDriverT* driver)
{
	int deceleration_time;
	int difference;
	
	switch((uint8_t)driver->Status.DriverState)
	{
		case MotorDriverStateEnabling:
			if (!driver->EnableDelay)
			{
				driver->Status.DriverState = MotorDriverStateIsEnable;
				driver->Interface->EventListener(driver, MotorDriverEventChangeDriverState, MotorDriverStateIsEnable, 0);
				driver->Interface->SetValue(driver, MotorDriverValueDriverEnableState, true);
			}
			else
			{
				driver->EnableDelay--;
				return;
			}
			
		case MotorDriverStateIsEnable:
			if (driver->Status.MotorState == MotorDriverMotorStateStopped)
			{
				if (driver->DisableDelay)
				{
					driver->DisableDelay--;
				}
				else
				{
					 MotorDriverDisable(driver);
				}
				return;
			}
			break;
			
		case MotorDriverStateDisable:
			return;
	}
	
	switch((uint8_t)driver->Status.MotorState)
	{
		case MotorDriverMotorStateStartingMove:
			driver->Status.MotorState = MotorDriverMotorStateInMoving;
			driver->Interface->EventListener(driver, MotorDriverEventChangeMotorState, MotorDriverMotorStateInMoving, 0);
			driver->Interface->SetValue(driver, MotorDriverValueMotorEnableState, true);
			
		case MotorDriverMotorStateInMoving:
			driver->Position = driver->Interface->GetValue(driver, MotorDriverValuePosition);
			
			if (!((driver->Diraction == MotorDriverMoveDiractionForward && driver->Position < driver->PositionRequest)
			|| (driver->Diraction == MotorDriverMoveDiractionBackward && driver->Position > driver->PositionRequest))
			|| driver->MoveTime >= driver->MoveTimeRequest)
			{
				driver->Status.MotorState = MotorDriverMotorStateStopped;
				driver->Interface->EventListener(driver, MotorDriverEventChangeMotorState, MotorDriverMotorStateStopped, 0);
				driver->Interface->SetValue(driver, MotorDriverValueMotorEnableState, false);
				return;
			}
			
			//deceleration_time = (int)((driver->Speed - driver->Options.StopSpeed) / driver->CalculatedValues.DecelerationStep);
			difference = (driver->PositionRequest - driver->Position) * driver->Diraction;
			
			if (difference <= driver->Values.DeccelarationSteps
			|| ((driver->MoveTimeRequest - driver->MoveTime) <= driver->Values.DecelerationTime))
			{
				driver->Speed -= driver->Values.DecelerationStep;
				if (driver->Speed < driver->Options.StopSpeed)
				{
					driver->Speed = driver->Options.StopSpeed;
				}
				
				driver->DebugValues.DecelerationTime++;
				driver->Values.dxSteps = driver->Speed / driver->Values.HandlerFrequency;
				driver->Interface->SetValue(driver, MotorDriverValueSpeed, driver->Speed);
			}
			else if (driver->Speed < driver->SpeedRequest)
			{
				driver->Speed += driver->Values.AccelerationStep;
				if (driver->Speed > driver->SpeedRequest)
				{
					driver->Speed = driver->SpeedRequest;
				}
				
				driver->DebugValues.AccelerationTime++;
				driver->Values.dxSteps = driver->Speed / driver->Values.HandlerFrequency; //dv * dt = ds
				
				driver->Interface->SetValue(driver, MotorDriverValueSpeed, driver->Speed);
				driver->DebugValues.AccelarationSteps = driver->Position;
			}
			
			driver->Values.Steps += driver->Values.dxSteps * (int)driver->Diraction;
			driver->MoveTime += 10;
			return;
			
		case MotorDriverMotorStateStopped:
			return;
	}
}
//==============================================================================
void MotorDriverPWMHandler(MotorDriverT* driver)
{
	if (driver->Position != driver->PositionRequest)
	{
		driver->Position += driver->Diraction;
	}
	else
	{
		driver->Status.MotorState = MotorDriverMotorStateStopped;
		driver->Interface->EventListener(driver, MotorDriverEventChangeMotorState, MotorDriverMotorStateStopped, 0);
		driver->Interface->SetValue(driver, MotorDriverValueDriverEnableState, false);
	}
}
//==============================================================================
static xResult CalculationRacingFallingForSteps(MotorDriverT* driver)
{
	float steps = (driver->PositionRequest - driver->Position) * driver->Diraction;
  float speed = driver->Options.StartSpeed;
  float speed_offset = 0;
	int time_move = driver->MoveTimeRequest;
	
	driver->Values.AccelerationTime = 0;
	driver->Values.DecelerationTime = 0;
	
	xMemorySet(&driver->DebugValues, 0, sizeof(driver->DebugValues));
	
  while (speed < driver->SpeedRequest && time_move > 0)
  {
    if ((speed - speed_offset) > driver->Options.StopSpeed)
    {
      speed_offset += driver->Values.DecelerationStep;
      driver->Values.DecelerationTime++;
    }
    else
		{
      speed += driver->Values.AccelerationStep;
      driver->Values.AccelerationTime++;
    }
		
		time_move--;
	}
	
	if (speed < driver->Options.StopSpeed)
	{
		driver->Values.DeccelarationSteps = driver->Options.StopSpeed;
	}
	
	driver->Values.DeccelarationSteps = (speed * speed - driver->Options.StopSpeed * driver->Options.StopSpeed)
	/ (driver->Options.Deceleration * 2);
	
	driver->Values.DecelerationTime = driver->MoveTimeRequest - driver->Values.DecelerationTime;
	
	return xResultAccept;
}
//==============================================================================
xResult MotorDriverSetOptions(MotorDriverT* driver, MotorDriverOptionsT* options)
{
	if (!driver || !options)
	{
		return xResultLinkError;
	}
	
	if (driver->Status.MotorState == MotorDriverMotorStateStopped)
	{
		xMemoryCopy(&driver->Options, options, sizeof(MotorDriverOptionsT));
		
		return xResultAccept;
	}
	
	return xResultBusy;
}
//==============================================================================
xResult MotorDriverSetPosition(MotorDriverT* driver,
																int position,
																float speed,
																int move_time)
{
	xResult result;
	MotorDriverLock(driver);
	
	if (driver->Status.MotorState != MotorDriverMotorStateStopped)
	{
		result = xResultBusy;
		goto end;
	}
	
	if (move_time == 0)
	{
		result = xResultInvalidParameter;
		goto end;
	}
	
	if (speed <= 0)
	{
		result = xResultInvalidParameter;
		goto end;
	}
	
	if (driver->PositionRequest < position)
	{
		driver->Diraction = MotorDriverMoveDiractionForward;
	}
	else if (driver->PositionRequest > position)
	{
		driver->Diraction = MotorDriverMoveDiractionBackward;
	}
	else if (position == driver->Position)
	{
		result = xResultInvalidParameter;
		goto end;
	}
	
	driver->MoveTime = 0;
	driver->MoveTimeRequest = move_time;
	driver->SpeedRequest = speed;
	driver->PositionRequest = position;
	driver->Speed = driver->Options.StartSpeed;
	driver->DisableDelay = driver->Options.DisableDelay;
	driver->Values.HandlerFrequency = driver->Interface->GetValue(driver, MotorDriverValueHandlerFrequency);

	driver->Values.AccelerationStep = driver->Options.Acceleration / driver->Values.HandlerFrequency;
	driver->Values.DecelerationStep = driver->Options.Deceleration / driver->Values.HandlerFrequency;
	
	driver->Values.dxSteps = driver->Speed / driver->Values.HandlerFrequency;
	//CalculationRacingFallingForTime(driver);
	CalculationRacingFallingForSteps(driver);

	driver->Interface->SetValue(driver, MotorDriverValueSpeed, driver->Speed);
	//driver->Control->SetFrequency(driver, driver->Options.Frequency);
	//driver->Control->SetPWMHandlerState(driver, MotorDriver_StateEnable);
	driver->Status.MotorState = MotorDriverMotorStateStartingMove;
	driver->Interface->EventListener(driver, MotorDriverEventChangeMotorState, MotorDriverMotorStateStartingMove, 0);
	MotorDriverEnable(driver);
	
	end:;
	MotorDriverUnlock(driver);
	return result;
}
//==============================================================================
xResult MotorDriverInit(MotorDriverT* driver,
												void* parent,
												void* adapter,
												MotorDriverInterfaceT* interface,
												MotorDriverOptionsT* options)
{
	if (driver && adapter && interface)
	{
		if (!driver->Description)
		{
			driver->Description = "MotorDriverT";
		}
		
		driver->Parent = parent;
		driver->Adapter = adapter;
		driver->Interface = interface;
		
		if (options)
		{
			xMemoryCopy(&driver->Options, options, sizeof(MotorDriverOptionsT));
		}
		
		driver->Status.IsInit = true;
		
		return xResultAccept;
	}
	return xResultLinkError;
}
//==============================================================================
