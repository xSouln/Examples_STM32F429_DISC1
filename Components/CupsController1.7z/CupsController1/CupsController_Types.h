//==============================================================================
#ifndef RGB_CUP_TYPES_H
#define RGB_CUP_TYPES_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
 extern "C" {
#endif 
//==============================================================================
#include <stdlib.h>
#include "main.h"
#include "WS2812/WS2812.h"
#include "Adapters/RGBCup_AdapterBase.h"
#include "Common/xRxTransaction.h"
#include "Registers/registers.h"
//==============================================================================
typedef struct
{
	uint8_t Green;
	uint8_t Red;
	uint8_t Blue;
	
} RGBPixelT;
//------------------------------------------------------------------------------
typedef enum
{
	RGBCupNumber1,
	RGBCupNumber2,
	RGBCupNumber3,
	RGBCupNumber4,
	
	RGBCupsCount
	
} RGBCupsNumbers;
//------------------------------------------------------------------------------
typedef enum
{
	RGBCup1 = 1 << RGBCupNumber1,
	RGBCup2 = 1 << RGBCupNumber2,
	RGBCup3 = 1 << RGBCupNumber3,
	RGBCup4 = 1 << RGBCupNumber4,
	
	RGBCupsAll = 0xff
	
} RGBCupSelector;
//------------------------------------------------------------------------------
typedef enum
{
	RGBCupEventIdle,
	RGBCupEventUpdateLayoutStarted,
	RGBCupEventUpdateLayoutComplite,
	
} RGBCupEventSelector;
//------------------------------------------------------------------------------
typedef enum
{
	RGBCupRequestIdle,
	
} RGBCupRequestSelector;
//------------------------------------------------------------------------------
typedef enum
{
	RGBCupValueIdle,
	
} RGBCupValueSelector;
//==============================================================================
typedef union
{
	struct
	{
		uint32_t DrawingIsEnable : 1;
	};
	uint32_t Value;
	
} RGBCupStatusT;
//------------------------------------------------------------------------------
typedef void (*RGBCupsEventListenerT)(void* cup, RGBCupEventSelector event, uint32_t args, uint32_t count);
typedef xResult (*RGBCupsRequestListenerT)(void* cup, RGBCupRequestSelector event, uint32_t args, uint32_t count);
//------------------------------------------------------------------------------
typedef struct
{
	RGBCupsEventListenerT EventListener;
	RGBCupsRequestListenerT RequestListener;
	
} RGBCupInterfaceT;
//------------------------------------------------------------------------------
typedef struct
{
	char* Description;
	uint8_t Id;
	
	int8_t Diraction;
	
	int16_t Steps;
	int16_t StepNumber;
	
	float GreenIncrement;
	float RedIncrement;
	float BlueIncrement;
	
} RGBCupDrawingTemplateT;
//------------------------------------------------------------------------------
typedef struct
{
	OBJECT_HEADER;
	
	RGBCupAdapterBaseT Adapter;
	RGBCupInterfaceT* Interface;
	
	RGBCupStatusT Status;
	WS2812_T Driver;
	
	RGBCupDrawingTemplateT DrawingTemplate;
	
	uint16_t PixelsCount;
	
	uint8_t Id;
	
	WS2812_BufT* DataBuffer;
	uint16_t DataBufferSize;
	
} RGBCupT;
//------------------------------------------------------------------------------
typedef struct
{
	void* Description;
	void* Parent;
	
	RGBCupT Cups[RGBCupsCount];
	
	xRxRequestT* Requests;
	
} RGBCupsControlT;
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif /* RGB_CUP_TYPES_H */
