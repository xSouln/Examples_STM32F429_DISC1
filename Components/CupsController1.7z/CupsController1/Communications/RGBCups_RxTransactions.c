/*
 *
 */
//==============================================================================
#include "RGBCups_RxTransactions.h"
//==============================================================================
static void SetColor(xRxRequestManagerT* manager, RGBCupsRequestSetColorT* request)
{
	WS2812_PixelT color =
	{
		.Blue = request->Color.Blue,
		.Red = request->Color.Red,
		.Green = request->Color.Green,
	};
	
	uint16_t result = RGBCupsSetColor(request->Selector, color);
	
	xRxPutInResponseBuffer(manager->RxLine, &result, sizeof(result));
}
//----------------------------------------------------------------------------
static void SetTemplaet(xRxRequestManagerT* manager, RGBCupsRequestSetTemplaetT* request)
{
	
	//xRxPutInResponseBuffer(manager->RxLine, &result, sizeof(result));
}
//==============================================================================
static void GetStatus(xRxRequestManagerT* manager)
{
	for (uint8_t i = 0; i < RGBCupsCount; i++)
	{
		xRxPutInResponseBuffer(manager->RxLine, &RGBCupsControl.Cups[i].Status, sizeof(RGBCupsControl.Cups[i].Status));
	}
}
//----------------------------------------------------------------------------
static void GetTemplaetId(xRxRequestManagerT* manager)
{
	for (uint8_t i = 0; i < RGBCupsCount; i++)
	{
		xRxPutInResponseBuffer(manager->RxLine, &RGBCupsControl.Cups[i].DrawingTemplate.Id, sizeof(RGBCupsControl.Cups[i].DrawingTemplate.Id));
	}
}
//==============================================================================
const xRxTransactionT RGBCupsTransactions[] =
{
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//GET
	{
		.Id = RGB_CUPS_GET_STATUS,
		.Action = (xRxTransactionAction)GetStatus,
	},
	
	{
		.Id = RGB_CUPS_GET_TEMPLATE_ID,
		.Action = (xRxTransactionAction)GetTemplaetId,
	},
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//SET
	{
		.Id = RGB_CUPS_SET_COLOR,
		.Action = (xRxTransactionAction)SetColor,
	},
	
	{
		.Id = RGB_CUPS_SET_TEMPLATE,
		.Action = (xRxTransactionAction)SetColor,
	},
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//TRY
	
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	// end of transactions marker
  { .Id = -1 }
};
//==============================================================================
