//==============================================================================
#include "RGBCups/Controls/RGBCups.h"
//==============================================================================
extern const xRxTransactionT RGBCupsTransactions[];

static const PacketHeaderT TransactionRequestHeader =
{
	.Identificator = (PacketIdentificatorT)TRANSACTION_REQUEST_IDENTIFICATOR,
	.DeviceKey = RGB_CUPS_DEVICE_KEY
};
//------------------------------------------------------------------------------
const xRxRequestT RGBCupsRxRequests[] =
{
  {
		.Header = (void*)&TransactionRequestHeader,
		.HeaderLength = sizeof(TransactionRequestHeader),
		.Action = (xRxRequestReceiverT)xRxTransactionRequestReceiver,
		.Content = (void*)&RGBCupsTransactions
	},
  { 0 }
};
//==============================================================================