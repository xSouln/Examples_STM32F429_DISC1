//==============================================================================
#ifndef RGB_CUPS_RX_TRANSACTIONS_H
#define RGB_CUPS_RX_TRANSACTIONS_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
 extern "C" {
#endif 
//==============================================================================
#include "Common/xRxTransaction.h"
#include "RGBCups/RGBCups_Info.h"
#include "RGBCups/Controls/RGBCups.h"
//==============================================================================
typedef enum
{
  RGB_CUPS_GET_FIRMWARE_VERSION = 100,
	RGB_CUPS_GET_PIXELS,
	RGB_CUPS_GET_STATUS,
	RGB_CUPS_GET_TEMPLATE_ID,
	
	RGB_CUPS_SET = 1000,
	RGB_CUPS_SET_PIXELS,
	RGB_CUPS_SET_PIXELS_STATE,
	RGB_CUPS_SET_COLOR,
	RGB_CUPS_SET_TEMPLATE,

	RGB_CUPS_TRY = 2000,
	RGB_CUPS_TRY_DRAWING_START,
	RGB_CUPS_TRY_DRAWING_STOP,

	RGB_CUPS_EVT = 10000,
	
} RGB_CUPS_TRANSACTIONS;
//==============================================================================
typedef struct
{
	uint8_t Selector;
	
	RGBPixelT Color;
	
} RGBCupsRequestSetColorT;
//------------------------------------------------------------------------------
typedef struct
{
	uint8_t CupSelector;
	uint8_t TemplaetSelector;
	
} RGBCupsRequestSetTemplaetT;
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif /* RGB_CUPS_RX_TRANSACTIONS_H */

