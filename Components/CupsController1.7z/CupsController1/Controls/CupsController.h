//==============================================================================
#ifndef RGB_CUPS_H
#define RGB_CUPS_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
 extern "C" {
#endif 
//==============================================================================
#include "RGBCups/RGBCups_Types.h"
#include "RGBCups/RGBCups_Info.h"
#include "RGBCups/RGBCups_Config.h"
#include "RGBCups/Communications/RGBCups_RxRequests.h"
#include "RGBCups/Adapters/RGBCup_Adapters.h"
#include "RGBCups/Logic/RGBCups_DrawManager.h"
//------------------------------------------------------------------------------
extern RGBCupsControlT RGBCupsControl;
//extern RGBCupT RGBCups[RGBCupsCount];
//==============================================================================
void RGBCupsHandler();
xResult RGBCupsInit(void* parent, RGBCupInterfaceT* interface);

extern xResult RGBCupsSetColor(RGBCupSelector cups, WS2812_PixelT pixel);
extern xResult RGBCupsUpdateLayout(RGBCupSelector cups, uint32_t time_out);

extern xResult RGBCupsDrawingStart(RGBCupSelector cups, RGBCupDrawingTemplateT* pattern);
extern xResult RGBCupsDrawingStop(RGBCupSelector cups);
extern void RGBCupsDraw(RGBCupSelector cups);
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif /* RGB_CUPS_H */
