//==============================================================================
#include "RGBCups.h"
#include "RGBCups/Adapters/RGBCup_Adapters.h"
//==============================================================================
//RGBCupT RGBCups[RGBCupsCount];
RGBCupsControlT RGBCupsControl;
//==============================================================================
void RGBCupsHandler()
{
	RGBCupsDraw(RGBCup1|RGBCup2);
	RGBCupsUpdateLayout(RGBCup1|RGBCup2, 1000);
}
//------------------------------------------------------------------------------
static xResult RGBCupsSetTemplate(RGBCupSelector cups, RGBCupDrawingTemplateT* pattern)
{
	uint8_t request = cups;
	uint8_t i = 0;
	
	if (pattern)
	{
		while (request && i < RGBCupsCount)
		{
			if ((request & 0x01))
			{
				RGBCupDrawManagerSetTemplate(&RGBCupsControl.Cups[i], pattern);
			}
			
			request >>= 1;
			i++;
		}
		
		return xResultAccept;
	}
	
	return xResultError;
}
//==============================================================================
xResult RGBCupsInit(void* parent, RGBCupInterfaceT* interface)
{
	extern const xRxRequestT RGBCupsRxRequests[];
	
	RGBCupsControl.Description = "RGBCupsControlT";
	RGBCupsControl.Parent = parent;
	RGBCupsControl.Requests = (xRxRequestT*)RGBCupsRxRequests;
	
	for (uint8_t i = 0; i < RGBCupsCount; i++)
	{
		RGBCupsControl.Cups[i].Description = "RGBCupsT";
		RGBCupsControl.Cups[i].Parent = &RGBCupsControl;
		RGBCupsControl.Cups[i].Interface = interface;
		
		RGBCupsControl.Cups[i].Id = i;
	}
	
	return xResultAccept;
}
//==============================================================================
