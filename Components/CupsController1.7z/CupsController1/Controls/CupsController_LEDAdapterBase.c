//==============================================================================
#include "RGBCup_AdapterBase.h"
//==============================================================================
static void Handler(void* device)
{
	
}
//------------------------------------------------------------------------------
static void EventListener(void* device, RGBCupAdapterEventSelector selector, uint32_t args, uint32_t count)
{
	switch ((int)selector)
	{
		default : break;
	}
}
//------------------------------------------------------------------------------
static xResult RequestListener(void* device, RGBCupAdapterRequestSelector selector, uint32_t args, uint32_t count)
{
	switch ((int)selector)
	{
		default : return xResultRequestIsNotFound;
	}
	
	return xResultAccept;
}
//------------------------------------------------------------------------------
static uint32_t GetValue(void* device, RGBCupAdapterValueSelector selector)
{
	switch ((int)selector)
	{
		default : break;
	}
	
	return 0;
}
//------------------------------------------------------------------------------
static xResult SetValue(void* device, RGBCupAdapterValueSelector selector, uint32_t value)
{
	switch ((int)selector)
	{
		default : return xResultValueIsNotFound;
	}
	
	return xResultAccept;
}
//==============================================================================
static RGBCupAdapterInterfaceT Interface =
{
	.Handler = (RGBCupAdapterHandlerT)Handler,
	.EventListener = (RGBCupAdapterEventListenerT)EventListener,
	.RequestListener = (RGBCupAdapterRequestListenerT)RequestListener,
	.GetValue = (RGBCupAdapterActionGetValueT)GetValue,
	.SetValue = (RGBCupAdapterActionSetValueT)SetValue,
};
//------------------------------------------------------------------------------
xResult RGBCupAdapterBaseInit(RGBCupAdapterBaseT* adapter, void* parent)
{
	if (adapter)
	{
		adapter->Description = "RGBCupAdapterBaseT";
		adapter->Parent = parent;
		adapter->Child = 0;
		
		adapter->Interface.Handler = (RGBCupAdapterHandlerT)Handler;
		adapter->Interface.EventListener = (RGBCupAdapterEventListenerT)EventListener;
		adapter->Interface.RequestListener = (RGBCupAdapterRequestListenerT)RequestListener;
		adapter->Interface.GetValue = (RGBCupAdapterActionGetValueT)GetValue;
		adapter->Interface.SetValue = (RGBCupAdapterActionSetValueT)SetValue;
		
		return xResultAccept;
	}
	
	return xResultLinkError;
}
//==============================================================================