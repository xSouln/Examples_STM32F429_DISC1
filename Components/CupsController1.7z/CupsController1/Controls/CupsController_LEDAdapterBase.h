//==============================================================================
#ifndef _RGB_CUP_ADAPTER_BASE_H
#define _RGB_CUP_ADAPTER_BASE_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
#include "Common/xTypes.h"
//==============================================================================
typedef enum
{
	RGBCupAdapterEventIdle,
	
} RGBCupAdapterEventSelector;
//------------------------------------------------------------------------------
typedef enum
{
	RGBCupAdapterRequestIdle,
	RGBCupAdapterRequestFillPixels,
	RGBCupAdapterRequestSetPixel,
	RGBCupAdapterRequestWritePixels
	
} RGBCupAdapterRequestSelector;
//------------------------------------------------------------------------------
typedef enum
{
	RGBCupAdapterValueIdle,
	
} RGBCupAdapterValueSelector;
//------------------------------------------------------------------------------
typedef void (*RGBCupAdapterHandlerT)(void* device);

typedef void (*RGBCupAdapterEventListenerT)(void* device, RGBCupAdapterEventSelector selector, uint32_t args, uint32_t count);
typedef xResult (*RGBCupAdapterRequestListenerT)(void* device, RGBCupAdapterRequestSelector selector, uint32_t args, uint32_t count);

typedef uint32_t (*RGBCupAdapterActionGetValueT)(void* device, RGBCupAdapterValueSelector selector);
typedef xResult (*RGBCupAdapterActionSetValueT)(void* device, RGBCupAdapterValueSelector selector, uint32_t value);
//------------------------------------------------------------------------------
typedef struct
{
	RGBCupAdapterHandlerT Handler;
	
	RGBCupAdapterEventListenerT EventListener;
	RGBCupAdapterRequestListenerT RequestListener;
	
	RGBCupAdapterActionGetValueT GetValue;
	RGBCupAdapterActionSetValueT SetValue;
	
} RGBCupAdapterInterfaceT;
//------------------------------------------------------------------------------
typedef struct
{
	OBJECT_HEADER;
	
	void* Child;
	RGBCupAdapterInterfaceT Interface;
	
} RGBCupAdapterBaseT;
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif