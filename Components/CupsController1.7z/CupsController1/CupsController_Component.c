//==============================================================================
#include "RGBCups_Component.h"
#include "tim.h"
//==============================================================================
WS2812_BufT data_buffer_cups_12[(RGB_CUPS_SYNC_START_DATA_COUNT
														+ RGB_CUPS_DATA_BUFFER_SIZE_CUP1
														+ RGB_CUPS_DATA_BUFFER_SIZE_CUP2
														+ RGB_CUPS_SYNC_END_DATA_COUNT)];
//------------------------------------------------------------------------------
WS2812_BufT data_buffer_cups_34[(RGB_CUPS_SYNC_START_DATA_COUNT
														+ RGB_CUPS_DATA_BUFFER_SIZE_CUP3
														+ RGB_CUPS_DATA_BUFFER_SIZE_CUP4
														+ RGB_CUPS_SYNC_END_DATA_COUNT)];
//------------------------------------------------------------------------------
//==============================================================================
RGBCupWS2812AdapterT AdapterCup12 =
{
	.Timer = TIM1,
	.DMA = DMA2_Stream5,
	
	.PWM_Channel = 1,
	
	.DrawMemory = data_buffer_cups_12,
	.DrawMemorySize = sizeof(data_buffer_cups_12) / sizeof(data_buffer_cups_12[0]),
};
//------------------------------------------------------------------------------
RGBCupWS2812AdapterT AdapterCup34 =
{
	.Timer = TIM1,
	.DMA = DMA2_Stream5,
	
	.PWM_Channel = 2,
	
	.DrawMemory = data_buffer_cups_34,
	.DrawMemorySize = sizeof(data_buffer_cups_34) / sizeof(data_buffer_cups_34[0])
};
//==============================================================================
static void EventListener(void* cup, RGBCupEventSelector event, uint32_t args, uint32_t count)
{
	switch ((uint8_t)event)
	{
		
		default : return;
	}
}
//==============================================================================
const static RGBCupInterfaceT Interface =
{
	.EventListener = (RGBCupsEventListenerT)EventListener
};
//==============================================================================
int RGBCupsComponentInit(void* parent)
{
	RGBCupsInit(parent, (RGBCupInterfaceT*)&Interface);
	
	uint16_t buffer_offset = RGB_CUPS_SYNC_START_DATA_COUNT;
	RGBCupsControl.Cups[RGBCupNumber1].DataBuffer = data_buffer_cups_12 + buffer_offset;
	RGBCupsControl.Cups[RGBCupNumber1].DataBufferSize = RGB_CUPS_DATA_BUFFER_SIZE_CUP1;
	buffer_offset += RGB_CUPS_DATA_BUFFER_SIZE_CUP1;
	
	RGBCupsControl.Cups[RGBCupNumber2].DataBuffer = data_buffer_cups_12 + buffer_offset;
	RGBCupsControl.Cups[RGBCupNumber2].DataBufferSize = RGB_CUPS_DATA_BUFFER_SIZE_CUP2;
	
	RGBCupWS2812AdapterInit(&RGBCupsControl.Cups[RGBCupNumber1], &AdapterCup12);
	RGBCupWS2812AdapterInit(&RGBCupsControl.Cups[RGBCupNumber2], &AdapterCup12);
	//----------------------------------------------------------------------------
	buffer_offset = RGB_CUPS_SYNC_START_DATA_COUNT;
	RGBCupsControl.Cups[RGBCupNumber3].DataBuffer = data_buffer_cups_34 + buffer_offset;
	RGBCupsControl.Cups[RGBCupNumber3].DataBufferSize = RGB_CUPS_DATA_BUFFER_SIZE_CUP3;
	buffer_offset += RGB_CUPS_DATA_BUFFER_SIZE_CUP3;
	
	RGBCupsControl.Cups[RGBCupNumber4].DataBuffer = data_buffer_cups_34 + buffer_offset;
	RGBCupsControl.Cups[RGBCupNumber4].DataBufferSize = RGB_CUPS_DATA_BUFFER_SIZE_CUP4;
	
	RGBCupWS2812AdapterInit(&RGBCupsControl.Cups[RGBCupNumber3], &AdapterCup34);
	RGBCupWS2812AdapterInit(&RGBCupsControl.Cups[RGBCupNumber4], &AdapterCup34);
	
	RGBCupsDrawManagerInit(&RGBCupsControl.Cups[RGBCupNumber1], &DrawingTemplate1);
	RGBCupsDrawManagerInit(&RGBCupsControl.Cups[RGBCupNumber2], &DrawingTemplate2);
	
	WS2812_DrawingStart(&RGBCupsControl.Cups[RGBCupNumber1].Driver.DrawManager);
	WS2812_DrawingStart(&RGBCupsControl.Cups[RGBCupNumber2].Driver.DrawManager);
	//----------------------------------------------------------------------------
	WS2812_PixelT Pixel =
	{
		.Green = 0x01,
		.Red = 0x01,
		.Blue = 0x01
	};
	
	WS2812_FillPixels(&RGBCupsControl.Cups[RGBCupNumber1].Driver, Pixel, 0, 8);
	WS2812_FillPixels(&RGBCupsControl.Cups[RGBCupNumber2].Driver, Pixel, 0, 8);
	WS2812_FillPixels(&RGBCupsControl.Cups[RGBCupNumber3].Driver, Pixel, 0, 8);
	WS2812_FillPixels(&RGBCupsControl.Cups[RGBCupNumber4].Driver, Pixel, 0, 8);
	
  return 0;
}
//==============================================================================
