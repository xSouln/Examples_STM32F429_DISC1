//==============================================================================
#ifndef RGB_CUPS_DRAW_MANAGER_H
#define RGB_CUPS_DRAW_MANAGER_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
#include "RGBCups/RGBCups_Types.h"
//==============================================================================
static const RGBCupDrawingTemplateT DrawingTemplate1 =
{
	.Id = 1,
	
	.Diraction = 1,
	.Steps = 10,
	
	.GreenIncrement = 1,
	.RedIncrement = 1,
	.BlueIncrement = 1,
};
//------------------------------------------------------------------------------
static const RGBCupDrawingTemplateT DrawingTemplate2 =
{
	.Id = 2,
	
	.Diraction = 1,
	.Steps = 10,
	
	.GreenIncrement = 0.1,
	.RedIncrement = 1,
	.BlueIncrement = 0.33,
};
//==============================================================================
xResult RGBCupsDrawManagerInit(RGBCupT* cup, const RGBCupDrawingTemplateT* drawing_template);

xResult RGBCupDrawManagerSetTemplate(RGBCupT* cup, RGBCupDrawingTemplateT* request);
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif
