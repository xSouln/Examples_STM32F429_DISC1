//==============================================================================
#include <string.h>
#include "RGBCups_DrawManager.h"
#include "WS2812/WS2812.h"
//==============================================================================
static char RGBCupDrawManagerDescription[] = "RGBCupDrawManagerT";
static char RGBCupDrawManagerTemplateDescription[] = "RGBCupDrawingTemplateT";
//==============================================================================
static void RGBCupsDrawingHandler(WS2812_DrawManagerBaseT* base)
{
	RGBCupDrawingTemplateT* drawing_template = (RGBCupDrawingTemplateT*)base->Child;
	RGBCupT* cup = base->Parent;
	
	if (drawing_template->StepNumber >= drawing_template->Steps)
	{
		drawing_template->StepNumber = drawing_template->Steps;
		drawing_template->Diraction = -1;
	}
	else if (drawing_template->StepNumber < 0)
	{
		drawing_template->StepNumber = 0;
		drawing_template->Diraction = 1;
	}
	
	WS2812_PixelT pixel =
	{
		.Green = (uint8_t)(drawing_template->GreenIncrement * drawing_template->StepNumber),
		.Red = (uint8_t)(drawing_template->RedIncrement * drawing_template->StepNumber),
		.Blue = (uint8_t)(drawing_template->BlueIncrement * drawing_template->StepNumber)
	};
	
	drawing_template->StepNumber += drawing_template->Diraction;
	
	WS2812_FillPixels(&cup->Driver, pixel, 0, cup->PixelsCount);
}
//------------------------------------------------------------------------------
xResult RGBCupDrawManagerSetTemplate(RGBCupT* cup, RGBCupDrawingTemplateT* request)
{
	if (request && memcmp(RGBCupDrawManagerTemplateDescription, request->Description, sizeof_str(RGBCupDrawManagerTemplateDescription)) == 0)
	{
		memcpy(&cup->DrawingTemplate, request, sizeof(cup->DrawingTemplate));
	}
	
	return xResultNotSupported;
}
//------------------------------------------------------------------------------
static xResult RequestListener(WS2812_DrawManagerBaseT* base, WS2812_DrawManagerRequestSelector selector, uint32_t args, uint32_t count)
{
	RGBCupT* cup = base->Parent;
	
	switch ((int)selector)
	{
		case WS2812_DrawManagerRequestDrawingStart:
			cup->Status.DrawingIsEnable = true;
			break;
		
		case WS2812_DrawManagerRequestDrawingStop:
			cup->Status.DrawingIsEnable = false;
			break;
		
		case WS2812_DrawManagerRequestSetTemplate:
			RGBCupDrawManagerSetTemplate(cup, (RGBCupDrawingTemplateT*)args);
			break;
		
		default : return xResultRequestIsNotFound;
	}
	
	return xResultAccept;
}
//==============================================================================
xResult RGBCupsDrawManagerInit(RGBCupT* cup, const RGBCupDrawingTemplateT* drawing_template)
{
	if (cup && drawing_template)
	{
		WS2812_DrawManagerBaseInit(&cup->Driver.DrawManager, cup);
		
		cup->Driver.DrawManager.Description = RGBCupDrawManagerDescription;
		cup->Driver.DrawManager.Child = &cup->DrawingTemplate;
		cup->DrawingTemplate.Description = RGBCupDrawManagerTemplateDescription;
		
		memcpy(&cup->DrawingTemplate, drawing_template, sizeof(cup->DrawingTemplate));
		
		cup->Driver.DrawManager.Interface.Handler = (WS2812_DrawManagerHandlerT)RGBCupsDrawingHandler;
		cup->Driver.DrawManager.Interface.RequestListener = (WS2812_DrawManagerRequestListenerT)RequestListener;
		
		return xResultAccept;
	}
	
	return xResultError;
}
//==============================================================================
