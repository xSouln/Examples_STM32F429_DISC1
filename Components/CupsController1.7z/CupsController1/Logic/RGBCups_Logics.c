//==============================================================================
#include <string.h>
#include "RGBCups/Logic/RGBCups_Logics.h"
#include "RGBCups/Controls/RGBCups.h"
#include "RGBCups/Adapters/RGBCup_Adapters.h" 
//==============================================================================
xResult RGBCupsSetColor(RGBCupSelector cups, WS2812_PixelT pixel)
{
	uint8_t request = cups;
	uint8_t i = 0;
	
	while (request && i < RGBCupsCount)
	{
		if (request & 0x01)
		{
			WS2812_FillPixels(&RGBCupsControl.Cups[i].Driver, pixel, 0, RGBCupsControl.Cups[i].PixelsCount);
		}
		
		request >>= 1;
		i++;
	}
	
	return xResultAccept;
}
//==============================================================================
xResult RGBCupsUpdateLayout(RGBCupSelector cups, uint32_t time_out)
{
	uint8_t request = cups;
	uint8_t i = 0;
	
	while (request && i < RGBCupsCount)
	{
		if (request & 0x03)
		{
			/*
			while (WS2812_GetTransmitterStatus(&RGBCups[i].Driver) != WS2812_TransmitterStopped && time_out)
			{
				if (!time_out)
				{
					return RGBCupsResultTimeOut;
				}
			}
			*/
			if (WS2812_GetTransmitterStatus(&RGBCupsControl.Cups[i].Driver) == WS2812_TransmitterStopped)
			{
				WS2812_UpdateLayout(&RGBCupsControl.Cups[i].Driver);
			}
		}
		
		request >>= 2;
		i += 2;
	}
	
	return xResultAccept;
}
//==============================================================================
xResult RGBCupsDrawingStart(RGBCupSelector cups, RGBCupDrawingTemplateT* pattern)
{
	uint8_t request = cups;
	uint8_t i = 0;
	
	if (pattern)
	{
		while (request && i < RGBCupsCount)
		{
			if ((request & 0x01))
			{
				/*
				xResult result = RGBCupsDrawManagerEx1Init(&RGBCupsControl.Cups[i], (RGBCupDrawManagerEx1T*)pattern);
				if (result == xResultAccept) { goto start; }
				
				result = RGBCupsDrawManagerEx2Init(&RGBCupsControl.Cups[i], (RGBCupDrawManagerEx2T*)pattern);
				
				start:;
				if (result == xResultAccept)
				{
					RGBCupsControl.Cups[i].DrawManagerPattern = pattern;
					WS2812_DrawingStart(&RGBCupsControl.Cups[i].Driver,
															(WS2812_DrawManagerBaseT*)RGBCupsControl.Cups[i].DrawManager,
															&RGBCupsControl.Cups[i].DrawManagerInterface);
				}
				*/
			}
			
			request >>= 1;
			i++;
		}
		
		return xResultAccept;
	}
	
	return xResultError;
}
//------------------------------------------------------------------------------
xResult RGBCupsDrawingStop(RGBCupSelector cups)
{
	uint8_t request = cups;
	uint8_t i = 0;
	
	while (request && i < RGBCupsCount)
	{
		if (request & 0x01)
		{
			WS2812_DrawingStop(&RGBCupsControl.Cups[i].Driver.DrawManager);
		}
		
		request >>= 1;
		i++;
	}
	
	return xResultAccept;
}
//------------------------------------------------------------------------------
void RGBCupsDraw(RGBCupSelector cups)
{
	uint8_t request = cups;
	uint8_t i = 0;
	
	while (request && i < RGBCupsCount)
	{
		if (request & 0x01)
		{
			//WS2812_Draw(&RGBCupsControl.Cups[i].Driver);
			WS2812_DrawManagerHandler(&RGBCupsControl.Cups[i].Driver.DrawManager);
		}
		
		request >>= 1;
		i++;
	}
}
//==============================================================================
